def say_hello():
    return (u'Hello World Ill be a python app :D ')

