# Example Package

This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.

To install under your local system use: "pip install -e ." the ".e" tag enables your source to be editable once you installed

To generate a zipfile to be distributed to spark cluster use: "python setup.py sdist"     